<?php

namespace App\Http\Controllers;

use App\Models\RouteStation;
use Illuminate\Http\Request;

class RouteStationController extends Controller
{
    public function index()
    {
        //
    }

}

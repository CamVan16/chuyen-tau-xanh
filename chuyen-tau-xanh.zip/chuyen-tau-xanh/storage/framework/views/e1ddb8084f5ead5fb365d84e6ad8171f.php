<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h2 class="text-primary text-center mb-4">QUÊN MÃ ĐẶT CHỖ</h2>

        <div class="alert alert-info">
            <p>Nhập email của bạn để nhận mã đặt chỗ qua email. Nếu bạn gặp khó khăn, vui lòng liên hệ với chúng tôi để được
                hỗ trợ.</p>
        </div>

        <div class="card shadow-sm p-4">
            <form action="<?php echo e(route('booking.forgot.process')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="email">Email <span class="text-danger">*</span></label>
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email')); ?>"
                        required placeholder="Nhập email đã đăng ký">
                </div>

                <?php if(session('success')): ?>
                    <div class="alert alert-success mt-2"><?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <?php if($errors->has('error')): ?>
                    <div class="alert alert-danger mt-2"><?php echo e($errors->first('error')); ?></div>
                <?php endif; ?>

                <div class="d-flex justify-content-between mt-3">
                    <button type="submit" class="btn btn-primary">Gửi mã</button>
                    <a href="<?php echo e(route('booking.lookup.form')); ?>" class="btn btn-link">Quay lại</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GitHub\chuyen-tau-xanh\chuyen-tau-xanh\resources\views/pages/forgot-booking-code.blade.php ENDPATH**/ ?>
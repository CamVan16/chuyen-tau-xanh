<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh sách mã đặt chỗ</title>
</head>
<body>
    <h1>Danh sách mã đặt chỗ của bạn</h1>
    <p>Xin chào,</p>
    <p>Dưới đây là danh sách các mã đặt chỗ của bạn:</p>

    <ul>
        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>Mã đặt chỗ: <?php echo e($booking->id); ?> (Khách hàng: <?php echo e($booking->customer->customer_name); ?>)</li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <p>Cảm ơn bạn đã sử dụng dịch vụ của chúng tôi.</p>
</body>
</html>
<?php /**PATH D:\GitHub\chuyen-tau-xanh\chuyen-tau-xanh\resources\views/emails/bookingCode.blade.php ENDPATH**/ ?>
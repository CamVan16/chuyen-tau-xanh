<?php $__env->startSection('content'); ?>
<script>
    $(document).ready(function() {
        const result = $('.transaction-result').data('result');
        if (result === "success") {
            localStorage.removeItem('ticket-pocket');
        }
    })
</script>
<div>
    <h1 class="text-center text-primary">THÔNG TIN GIAO DỊCH</h1>

    <div data-result="<?php echo e($status); ?>" class="transaction-result">
        <?php if($status !== 'success'): ?>
            <h3 style="color: red;" class="text-center">Thanh toán không thành công</h3>
            <span class="text-center">Đã có lỗi xảy ra. Vui lòng thử lại!</span>
        <?php else: ?>
            <div class="booker-info">
                <h3 class="text-primary">Mã đơn đặt của bạn:</strong> <?php echo e($booking_id); ?></h3>
                <h3>Thông tin người đặt</h3>
                <p><strong>Họ tên:</strong> <?php echo e($booking['booker']['name']); ?></p>
                <p><strong>Email:</strong> <?php echo e($booking['booker']['email'] ?: 'Không có'); ?></p>
                <p><strong>Số định danh:</strong> <?php echo e($booking['booker']['citizen']); ?></p>
                <p><strong>Số điện thoại:</strong> <?php echo e($booking['booker']['phone']); ?></p>
            </div>

            <div class="ticket-info">
                <h3>Thông tin vé</h3>
                <table border="1" style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr>
                            <th>Thông tin hành khách</th>
                            <th>Thông tin vé</th>
                            <th>Thành tiền</th>
                            <th>Tình trạng</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $booking['tickets']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    Họ tên:<?php echo e($ticket['passenger_name']); ?> <br>
                                    Đối tượng: <?php echo e($ticket['customer_type']); ?> <br>
                                    Số định danh: <?php echo e($ticket['passenger_citizen']); ?> <br>
                                </td>
                                <td>
                                    <?php echo e($ticket['train_mark']); ?> <br>
                                    Khởi hành: <?php echo e($ticket['day_start']); ?> <?php echo e($ticket['time_start']); ?> (<?php echo e($ticket['station_start']); ?>) <br>
                                    Toa: <?php echo e($ticket['car_name']); ?>, Ghế số: <?php echo e($ticket['seat_number']); ?> <br>
                                </td>
                                <td><?php echo e(number_format($ticket['money'], 0, ',', '.')); ?> VND</td>
                                <td>Đã thanh toán</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GitHub\chuyen-tau-xanh\chuyen-tau-xanh\resources\views/pages/transaction_information.blade.php ENDPATH**/ ?>
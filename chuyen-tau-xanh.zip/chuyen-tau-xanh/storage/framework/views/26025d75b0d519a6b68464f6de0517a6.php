
<script>document.documentElement.setAttribute("data-bs-theme", localStorage.colorMode ?? 'light');</script>

<?php Basset::basset('https://unpkg.com/@tabler/core@1.0.0-beta19/dist/css/tabler.min.css'); ?>
<?php Basset::basset(base_path('vendor/backpack/theme-tabler/resources/assets/css/style.css')); ?><?php /**PATH D:\GitHub\chuyen-tau-xanh\chuyen-tau-xanh\vendor/backpack/theme-tabler/resources/views/inc/theme_styles.blade.php ENDPATH**/ ?>
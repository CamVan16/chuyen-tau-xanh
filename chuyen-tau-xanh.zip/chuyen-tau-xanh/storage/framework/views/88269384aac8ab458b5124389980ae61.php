<?php
  $error_number = 404;
?>

<?php echo $__env->make(backpack_view('errors.4xx'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GitHub\chuyen-tau-xanh\chuyen-tau-xanh\vendor/backpack/crud/src/resources/views/ui/errors/404.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <!-- Title -->
    <h3 class="text-center mb-4">Thông tin giao dịch đổi vé</h3>

    <!-- Transaction Status -->
    <div class="alert alert-info">
        <h5>Kết quả giao dịch:
            <?php if($status === 'success'): ?>
                <span class="text-success">Thành công</span>
            <?php else: ?>
                <span class="text-danger">Thất bại</span>
            <?php endif; ?>
        </h5>
    </div>

    <!-- Old Ticket Info -->
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">Thông tin vé cũ</div>
        <div class="card-body">
            <ul class="list-unstyled">
                <li><strong>Mã vé cũ:</strong> <?php echo e($newExchange->old_ticket_id ?? 'Không có dữ liệu'); ?></li>
                <li><strong>Giá vé cũ:</strong> <?php echo e(number_format($newExchange->old_price ?? 0, 0, ',', '.')); ?> VND</li>
            </ul>
        </div>
    </div>

    <!-- New Ticket Info -->
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">Thông tin vé mới</div>
        <div class="card-body">
            <ul class="list-unstyled">
                <li><strong>Mã đặt vé mới:</strong> <?php echo e($newExchange->newBookingId ?? 'Không có dữ liệu'); ?></li>
                <li><strong>Mã vé mới:</strong> <?php echo e($newExchange->new_ticket_id ?? 'Không có dữ liệu'); ?></li>
                <li><strong>Giá vé mới:</strong> <?php echo e(number_format($newExchange->new_price ?? 0, 0, ',', '.')); ?> VND</li>
            </ul>
        </div>
    </div>

    <!-- Payment Info -->
    <div class="mt-4">
        <h3 class="text-center mb-3">Thông tin thanh toán</h3>
        <p><strong>Phương thức thanh toán:</strong> <?php echo e($payment ?? 'Không có thông tin'); ?></p>
        <p><strong>Tiền phải trả:</strong> <?php echo e(number_format($newExchange->additional_price ?? 0, 0, ',', '.')); ?> VND</p>

        <?php if($status === 'success'): ?>
            <div class="alert alert-success">
                <strong>Giao dịch thành công!</strong>
            </div>
        <?php else: ?>
            <div class="alert alert-danger">
                <strong>Giao dịch thất bại!</strong>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GitHub\chuyen-tau-xanh\chuyen-tau-xanh\resources\views/pages/transaction_information_exchange.blade.php ENDPATH**/ ?>
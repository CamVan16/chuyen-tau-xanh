<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="d-flex justify-content-between mb-4">
            <div class="step text-center">
                <span class="badge badge-primary">1</span>
                <p>Chọn vé cần trả</p>
            </div>
            <div class="step text-center">
                <span class="badge badge-secondary">2</span>
                <p>Xác nhận</p>
            </div>
            <div class="step text-center">
                <span class="badge badge-secondary">3</span>
                <p>Hoàn tất</p>
            </div>
        </div>

        <h2 class="text-primary">CHỌN VÉ CẦN TRẢ</h2>

        <!-- Thông tin Booking -->
        <div class="mb-4">
            <h4 class="mb-3">Thông tin đặt vé</h4>
            <table class="table table-bordered">
                <tr>
                    <th>Mã đặt vé</th>
                    <td><?php echo e($booking->id); ?></>
                    </td>
                </tr>
                <tr>
                    <th>Họ tên</th>
                    <td><?php echo e($booking->customer->customer_name); ?></td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td><?php echo e($booking->customer->email); ?></td>
                </tr>
                <tr>
                    <th>Số điện thoại</th>
                    <td><?php echo e($booking->customer->phone); ?></td>
                </tr>
            </table>
        </div>

        <!-- Danh sách vé -->
        <h4 class="mb-3">Các giao dịch thành công:</h4>
        <?php if($tickets->isEmpty()): ?>
            <div class="alert alert-warning">
                Không có vé nào để trả cho mã đặt chỗ này.
            </div>
        <?php else: ?>
            <form action="<?php echo e(route('refund.createRefund')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="booking_id" value="<?php echo e($booking->id); ?>">

                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Họ tên</th>
                            <th>Thông tin vé</th>
                            <th>Thành tiền (VND)</th>
                            <th>Lệ phí trả vé</th>
                            <th>Tiền trả lại</th>
                            <th>Trạng thái</th>
                            <th>Chọn vé trả</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td class="text-start">
                                    <p><?php echo e($ticket->customer->customer_name); ?></p>
                                    <p>Đối tượng: <?php echo e($ticket->customer->customer_type); ?></p>
                                    <p>Số giấy tờ: <?php echo e($ticket->customer->citizen_id); ?></p>
                                </td>
                                <td class="text-start">
                                    <p><strong>Mã vé:</strong> <?php echo e($ticket?->id); ?></p>
                                    <p><strong>Mã tàu:</strong> <?php echo e($ticket?->schedule?->train_mark); ?></p>
                                    <p><?php echo e($ticket?->schedule?->day_start); ?> <?php echo e($ticket?->schedule?->time_start); ?></p>
                                    <p><strong>Toa:</strong> <?php echo e($ticket?->schedule?->car_name); ?> - Ghế:
                                        <?php echo e($ticket?->schedule?->seat_number); ?></p>
                                </td>
                                <td><?php echo e(number_format($ticket->price - $ticket->discount_price, 0, ',', '.')); ?></td>
                                <?php if($ticket->refund_fee !== 1): ?>
                                    <td><?php echo e(number_format($ticket->refund_fee * $ticket->price, 0, ',', '.')); ?></td>
                                    <td class="refund-return"><?php echo e(number_format($ticket->price * (1- $ticket->refund_fee) - $ticket->discount_price , 0, ',', '.')); ?>

                                    </td>
                                <?php else: ?>
                                    <td>X</td>
                                    <td class="refund-return">X</td>
                                <?php endif; ?>
                                <td>
                                    <?php if($ticket->exchange): ?>
                                        <?php switch($ticket->exchange->exchange_status):
                                            case ('completed'): ?>
                                                <span class="badge badge-success">Đã đổi vé</span>
                                            <?php break; ?>

                                            <?php case ('pending'): ?>
                                                <span class="badge badge-warning">Đang chờ xử lý</span>
                                            <?php break; ?>

                                            <?php case ('rejected'): ?>
                                                <span class="badge badge-danger">Đã hủy đổi vé</span>
                                            <?php break; ?>
                                        <?php endswitch; ?>
                                    <?php elseif($ticket->refund): ?>
                                        <?php switch($ticket->refund->refund_status):
                                            case ('completed'): ?>
                                                <span class="badge badge-success">Đã trả vé</span>
                                            <?php break; ?>

                                            <?php case ('pending'): ?>
                                                <span class="badge badge-warning">Đang chờ xử lý</span>
                                            <?php break; ?>

                                            <?php case ('rejected'): ?>
                                                <span class="badge badge-danger">Đã hủy trả vé</span>
                                            <?php break; ?>
                                        <?php endswitch; ?>
                                    <?php else: ?>
                                        <span class="badge badge-secondary">Chưa có vé đổi</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <input type="checkbox" name="ticket_array[]" value="<?php echo e($ticket->id); ?>"
                                        id="ticket_<?php echo e($ticket->id); ?>" class="ticket-checkbox"
                                        <?php if($ticket->exchange?->exchange_status === 'completed'): ?> disabled
                                        <?php elseif($ticket->refund?->refund_status === 'completed'): ?>
                                            disabled <?php endif; ?> />
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <div class="mt-4 text-center">
                    <button type="submit" class="btn btn-primary" id="submit-button" disabled>Gửi yêu cầu hoàn vé</button>
                </div>
            </form>
        <?php endif; ?>
    </div>

    <style>
        .step {
            flex: 1;
        }

        .step .badge {
            font-size: 1.2em;
            padding: 10px;
        }

        .step p {
            margin-top: 10px;
        }

        th,
        td {
            text-align: center;
        }

        .text-start {
            text-align: start;
        }

        p {
            margin: 0;
        }
    </style>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const checkboxes = document.querySelectorAll('.ticket-checkbox');
            const submitButton = document.getElementById('submit-button');

            checkboxes.forEach(checkbox => {
                const row = checkbox.closest('tr');

                const refundCell = row.querySelector('.refund-return');
                const refundValue = refundCell?.textContent.trim();

                if (refundValue === 'X') {
                    checkbox.disabled = true;
                }

                checkbox.addEventListener('change', function() {
                    const isAnyChecked = Array.from(checkboxes).some(cb => cb.checked);
                    submitButton.disabled = !isAnyChecked;
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GitHub\chuyen-tau-xanh\chuyen-tau-xanh\resources\views/pages/refund-selection.blade.php ENDPATH**/ ?>
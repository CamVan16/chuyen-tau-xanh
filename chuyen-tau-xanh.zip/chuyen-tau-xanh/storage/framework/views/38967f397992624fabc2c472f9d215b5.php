<!DOCTYPE html>
<html>
<head>
    <title><?php echo e($details['subject'] ?? 'Thông báo'); ?></title>
</head>
<body>
    <h1><?php echo e($details['subject'] ?? 'Thông báo từ hệ thống'); ?></h1>
    <p>Xin chào,</p>
    <p>Mã đặt chỗ của bạn: <?php echo e($details['booking_id'] ?? 'Không có mã đặt chỗ'); ?></p>
    <p>Mã xác nhận hoàn vé: <?php echo e($details['confirmation_code'] ?? 'Không có mã xác nhận'); ?></p>
    <p>Vui lòng sử dụng mã này để xác nhận yêu cầu hoàn vé của bạn.</p>
    <p>Trân trọng,</p>
    <p>Đội ngũ hỗ trợ</p>
</body>
</html>
<?php /**PATH D:\GitHub\chuyen-tau-xanh\chuyen-tau-xanh\resources\views/emails/refund-confirmation.blade.php ENDPATH**/ ?>
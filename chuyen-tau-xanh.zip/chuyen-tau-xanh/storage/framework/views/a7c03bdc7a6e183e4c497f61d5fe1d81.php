
<link href="<?php echo e(asset('css/admin-custom.css')); ?>" rel="stylesheet">

<li class="nav-item">
    <a class="nav-link" href="<?php echo e(backpack_url('dashboard')); ?>">
        <i class="la la-home nav-icon"></i> <?php echo e(trans('backpack::base.dashboard')); ?>

    </a>
</li>


<li class="nav-item menu-group">
    <a class="nav-link" href="#" onclick="toggleMenu('booking-menu')">
        <i class="la la-ticket-alt nav-icon"></i> Quản lý vé tàu
    </a>
    <ul class="nav nav-treeview" id="booking-menu"
        style="<?php echo e(request()->is('admin/customer*', 'admin/booking*', 'admin/schedule*', 'admin/ticket*', 'admin/refund*', 'admin/exchange*') ? 'display: block;' : 'display: none;'); ?>">
        <li class="nav-item"><a class="nav-link <?php echo e(request()->is('admin/customer*') ? 'active' : ''); ?>"
                href="<?php echo e(backpack_url('customer')); ?>"><i class="la la-users nav-icon"></i> Khách hàng</a></li>
        <li class="nav-item"><a class="nav-link <?php echo e(request()->is('admin/booking*') ? 'active' : ''); ?>"
                href="<?php echo e(backpack_url('booking')); ?>"><i class="la la-calendar-check nav-icon"></i> Đặt vé</a></li>
        <li class="nav-item"><a class="nav-link <?php echo e(request()->is('admin/schedule*') ? 'active' : ''); ?>"
                href="<?php echo e(backpack_url('schedule')); ?>"><i class="la la-clock nav-icon"></i> Lịch trình</a></li>
        <li class="nav-item"><a class="nav-link <?php echo e(request()->is('admin/ticket*') ? 'active' : ''); ?>"
                href="<?php echo e(backpack_url('ticket')); ?>"><i class="la la-ticket-alt nav-icon"></i> Vé</a></li>
        <li class="nav-item"><a class="nav-link <?php echo e(request()->is('admin/refund*') ? 'active' : ''); ?>"
                href="<?php echo e(backpack_url('refund')); ?>"><i class="la la-undo nav-icon"></i> Trả vé</a></li>
        <li class="nav-item"><a class="nav-link <?php echo e(request()->is('admin/exchange*') ? 'active' : ''); ?>"
                href="<?php echo e(backpack_url('exchange')); ?>"><i class="la la-sync-alt nav-icon"></i> Đổi vé</a></li>
    </ul>
</li>


<li class="nav-item menu-group">
    <a class="nav-link" href="#" onclick="toggleMenu('train-menu')">
        <i class="la la-train nav-icon"></i> Quản lý tàu
    </a>
    <ul class="nav nav-treeview" id="train-menu"
        style="<?php echo e(request()->is('admin/route*', 'admin/train*', 'admin/car*', 'admin/seat*', 'admin/seat-type*') ? 'display: block;' : 'display: none;'); ?>">
        <li class="nav-item"><a class="nav-link <?php echo e(request()->is('admin/route*') ? 'active' : ''); ?>"
                href="<?php echo e(backpack_url('route')); ?>"><i class="la la-route nav-icon"></i> Tuyến</a></li>
        <li class="nav-item"><a class="nav-link <?php echo e(request()->is('admin/train*') ? 'active' : ''); ?>"
                href="<?php echo e(backpack_url('train')); ?>"><i class="la la-train nav-icon"></i> Tàu</a></li>
        
        <li class="nav-item"><a class="nav-link <?php echo e(request()->is('admin/station-area*') ? 'active' : ''); ?>"
                href="<?php echo e(backpack_url('station-area')); ?>"><i class="la la-map-marker-alt nav-icon"></i> Ga</a></li>
        
        <li class="nav-item"><a class="nav-link <?php echo e(request()->is('admin/car*') ? 'active' : ''); ?>"
                href="<?php echo e(backpack_url('car')); ?>"><i class="la la-subway nav-icon"></i> Toa tàu</a></li>
        <li class="nav-item"><a class="nav-link <?php echo e(request()->is('admin/seat*') ? 'active' : ''); ?>"
                href="<?php echo e(backpack_url('seat')); ?>"><i class="la la-chair nav-icon"></i> Ghế</a></li>
        <li class="nav-item"><a class="nav-link <?php echo e(request()->is('admin/seat-type*') ? 'active' : ''); ?>"
                href="<?php echo e(backpack_url('seat-type')); ?>"><i class="la la-cogs nav-icon"></i> Loại ghế</a></li>

    </ul>
</li>


<li class="nav-item menu-group">
    <a class="nav-link" href="#" onclick="toggleMenu('voucher-menu')">
        <i class="la la-gift nav-icon"></i> Quản lý khuyến mãi
    </a>
    <ul class="nav nav-treeview" id="voucher-menu"
        style="<?php echo e(request()->is('admin/voucher*') ? 'display: block;' : 'display: none;'); ?>">
        <li class="nav-item"><a class="nav-link <?php echo e(request()->is('admin/voucher*') ? 'active' : ''); ?>"
                href="<?php echo e(backpack_url('voucher')); ?>"><i class="la la-percent nav-icon"></i> Khuyến mãi</a></li>
    </ul>
</li>


<li class="nav-item menu-group">
    <a class="nav-link" href="#" onclick="toggleMenu('policy-menu')">
        <i class="la la-clipboard-list nav-icon"></i> Quản lý chính sách
    </a>
    <ul class="nav nav-treeview" id="policy-menu"
        style="<?php echo e(request()->is('admin/refund-policy*', 'admin/exchange-policy*') ? 'display: block;' : 'display: none;'); ?>">
        <li class="nav-item"><a class="nav-link <?php echo e(request()->is('admin/refund-policy*') ? 'active' : ''); ?>"
                href="<?php echo e(backpack_url('refund-policy')); ?>"><i class="la la-exchange-alt nav-icon"></i> Chính sách trả
                vé</a></li>
        <li class="nav-item"><a class="nav-link <?php echo e(request()->is('admin/exchange-policy*') ? 'active' : ''); ?>"
                href="<?php echo e(backpack_url('exchange-policy')); ?>"><i class="la la-retweet nav-icon"></i> Chính sách đổi
                vé</a></li>
    </ul>
</li>

<script>
    function toggleMenu(menuId) {
        var menu = document.getElementById(menuId);
        if (menu.style.display === "none" || menu.style.display === "") {
            menu.style.display = "block";
        } else {
            menu.style.display = "none";
        }
    }

    document.addEventListener('DOMContentLoaded', function() {
        var activeLinks = document.querySelectorAll('.nav-link.active');
        activeLinks.forEach(function(link) {
            var parentMenu = link.closest('.nav-treeview');
            if (parentMenu) {
                parentMenu.style.display = 'block';
            }
        });
    });
</script>
<?php /**PATH D:\GitHub\chuyen-tau-xanh\chuyen-tau-xanh\resources\views/vendor/backpack/ui/inc/menu_items.blade.php ENDPATH**/ ?>
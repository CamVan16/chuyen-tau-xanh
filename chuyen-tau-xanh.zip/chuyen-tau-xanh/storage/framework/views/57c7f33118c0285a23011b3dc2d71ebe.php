<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h2 class="text-primary">CHI TIẾT GIAO DỊCH HOÀN TIỀN</h2>

        <div class="mb-4">
            <table class="table table-bordered">
                <tr>
                    <th>Mã đặt chỗ</th>
                    <td><?php echo e($refund->booking_id); ?></>
                    </td>
                </tr>
                <tr>
                    <th>Ngày trả vé</th>
                    <td><?php echo e($refund->refund_time); ?></td>
                </tr>
                <tr>
                    <th>Số tiền hoàn</th>
                    <td><?php echo e(number_format($refund->refund_amount)); ?> VNĐ</td>
                </tr>
            </table>
        </div>

        <h4 class="mt-4">Danh sách vé đã hủy:</h4>
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th class="text-start">Họ tên</th>
                    <th>Thông tin vé</th>
                    <th>Thành tiền (VND)</th>
                    <th>Lệ phí trả vé</th>
                    <th>Tiền trả lại</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td class="text-start">
                            <p><?php echo e($ticket->customer->customer_name); ?></p>
                            <p><?php echo e($ticket->customer->customer_type); ?></p>
                            <p>Số giấy tờ: <?php echo e($ticket->customer->citizen_id); ?></p>
                        </td>
                        <td class="text-start">
                            <p>Mã vé: <?php echo e($ticket->id); ?></p>
                            <p>Mã tàu: <?php echo e($ticket?->schedule?->train_mark); ?></p>
                            <p><?php echo e($ticket?->schedule?->day_start); ?> <?php echo e($ticket?->schedule?->time_start); ?></p>
                            <p>Toa <?php echo e($ticket?->schedule?->car_name); ?> | Ghế <?php echo e($ticket?->schedule?->seat_number); ?></p>
                        </td>
                        <td><?php echo e(number_format($ticket->price - $ticket->discount_price), 0, ',', '.'); ?></td>
                        <td><?php echo e(number_format($ticket->refund_fee * $ticket->price, 0, ',', '.')); ?></td>
                        <td><?php echo e(number_format($ticket->price * (1 - $ticket->refund_fee)  - $ticket->discount_price, 0, ',', '.')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <a href="<?php echo e(route('refund.success', ['refund_id' => $refund->id])); ?>" class="btn btn-primary mt-4">Quay lại</a>
    </div>
    <style>
        th,
        td {
            text-align: center;
        }

        .text-start {
            text-align: start;
        }

        p {
            margin: 0;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GitHub\chuyen-tau-xanh\chuyen-tau-xanh\resources\views/pages/refund-details.blade.php ENDPATH**/ ?>